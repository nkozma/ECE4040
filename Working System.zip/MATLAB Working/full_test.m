Email_Setup;
[x,y,z]=FileImport('COM8', 'DREAD.txt');
%% 
figure(1)
plot(x)
title('Single-axis direction swithing error plot')
xlabel('Sample number')
ylabel('Error (\muT)')

figure(2)
plot(y)
title('Single-axis direction swithing error plot')
xlabel('Sample number')
ylabel('Error (\muT)')

% figure(3)
% plot(z)
% title('z error')