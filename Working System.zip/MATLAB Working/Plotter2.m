t=linspace(0,10,114);
n=zeros(1,114)';

figure(1)
plot(t,x,t,n,'--')
title('X_e_r_r_o_r vs Time')
xlabel('Time [s]')
ylabel('X_e_r_r_o_r [\muT]')

figure(2)
plot(t,y,t,n,'--')
title('Y_e_r_r_o_r vs Time')
xlabel('Time [s]')
ylabel('Y_e_r_r_o_r [\muT]')

n=ones(114/2,1)';
XfieldLevel=[(n*-84),(n*7.5)];
YfieldLevel=[(n*39),(n*125)];
Xfield=XfieldLevel-x;
Yfield=YfieldLevel-y;

figure(3)
plot(t,Xfield,t, XfieldLevel, '--');
title('X_f_i_e_l_d vs Time')
xlabel('Time [s]')
ylabel('X_f_i_e_l_d [\muT]')

figure(4)
plot(t,Yfield, t, YfieldLevel,'--');
title('Y_f_i_e_l_d vs Time')
xlabel('Time [s]')
ylabel('Y_f_i_e_l_d [\muT]')