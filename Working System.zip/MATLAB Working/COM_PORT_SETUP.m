function [s]= COM_PORT_SETUP(COM)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
close all; % close all windows to prevent contention
s = serial(COM); %assigns the object s to serial port
set(s, 'InputBufferSize', 100); %number of bytes in inout buffer
set(s, 'FlowControl', 'none');
%set(s, 'BaudRate', 115200); 
set(s, 'BaudRate', 9600);
set(s, 'Parity', 'none');
set(s, 'DataBits', 8);
set(s, 'StopBit', 1);
set(s, 'Timeout',1);
s.Terminator='LF/CR';

disp(get(s,'Name'));
prop(1)=(get(s,'BaudRate'));
prop(2)=(get(s,'DataBits'));
prop(3)=(get(s, 'StopBit'));
prop(4)=(get(s, 'InputBufferSize'));
disp(['Port Setup Done!!',num2str(prop)])

try
        fopen(s);           %opens the serial port
catch err
        fclose(instrfind);
        delete(s);
        delete(instrfindall);
        clear s;
        clear all;
        close all;
        error('Make sure you select the correct COM Port where the mbed is connected, or power cycle the mbed.');
end 

end

