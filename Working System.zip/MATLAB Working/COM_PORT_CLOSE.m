function [] = COM_PORT_CLOSE(s)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here

fclose(s); %close the serial port
delete(s);
delete(instrfindall);
clear s;

end

