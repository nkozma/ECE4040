function [x,y,z] = FileImport(COM, FILE)
init = 'cb';
row = 0;
SendSignal = 'd';
itr=1;
file = csvread(FILE,row);
  
s = COM_PORT_SETUP(COM);
fprintf(s,'%s',init);

      flag=1;
        while (flag==1)
            if(s.BytesAvailable>0)
                ReceivedChar=fscanf(s);
                disp(ReceivedChar(1))
                flag=0;
           end
        end

    while(file(row+1,1) ~= -500||ReceivedChar(1)=='q')
        xdat = num2str(file((row+1),1));
        ydat = num2str(file((row+1),2));
        zdat = num2str(file((row+1),3));
        simtime = num2str(file((row+1),4));
        
            if(length(xdat)<5)
                xdat = strcat(xdat,'.');
                n = 5-length(xdat);
                for i = 1:n
                    xdat = strcat(xdat,'0');
                end
            end

            if(length(ydat)<5)
                ydat = strcat(ydat,'.');
                n = 5-length(ydat);
                for i = 1:n
                    ydat = strcat(ydat,'0');
                end
            end

            if(length(zdat)<5)
                zdat = strcat(zdat,'.');
                n = 5-length(zdat);
                for i = 1:n
                    zdat = strcat(zdat,'0');
                end
            end

            if(length(simtime)<5)
                simtime = strcat(simtime,'.');
                n = 5-length(simtime);
                for i = 1:n
                    simtime = strcat(simtime,'0');
                end
            end
        
%         disp(xdat);
%         disp(ydat);
%         disp(zdat);
%         disp(simtime)
    if(ReceivedChar(1) == SendSignal)
            fprintf(s,'%s',xdat(1:5));
            fprintf(s,'%s',ydat(1:5));
            fprintf(s,'%s',zdat(1:5));
            fprintf(s,'%s',simtime(1:5));
            disp('d');
            row = row + 1;
    end
        
    if(ReceivedChar(1)=='q')
    a=1;
    while a<4
        flag=1;
        while (flag==1)
            if(s.BytesAvailable>0)
                ReceivedChar=fread(s,4,'uint8'); 
                Dat = uint8(ReceivedChar);
                Dat = typecast(Dat,'single');
                flag=0;
            end
            
        end
        switch a
            case 1
                %fprintf(strcat('Xerror:',ReceivedChar(1:4),''))
                %fprintf(' \n');
                %fprintf(' ')
                x(itr)=Dat;
            case 2
                 %fprintf(strcat('Yerror:',ReceivedChar(1:4),''))
                 y(itr)=Dat;
            case 3
                %fprintf(strcat('Zerror:',ReceivedChar(1:4),''))
                z(itr)=Dat;
                itr=itr+1;
        end
       a=a+1;
    end
    end
    
    if(Recievedchar(1)=='a')
        
    end
          flag=1;
        while (flag==1)
            if(s.BytesAvailable>0)
                ReceivedChar=fscanf(s);
                %disp(ReceivedChar(1))
                flag=0;
           end
        end    
    end
    
    fprintf(s,'%s','S0000');
    COM_PORT_CLOSE(s);
    clear s;